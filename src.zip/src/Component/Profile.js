// Profile.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './profilecss.css';

const Profile = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    console.log(userId)
    console.log('prakash', token)
    if (token) {
      axios.get('http://localhost:5000/profile', { // Change the endpoint to fetch user profile
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then(response => {
          console.log('presp', response)
          const restsr = response.data
          console.log('res',restsr.username)
          setUser(restsr);
        })
        .catch(error => {
          console.error('Error fetching user profile:', error);
        });
    }
  }, []);

  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <div className="profile-container">
      <h2>User Profile</h2>
      <div className="profile-info">
        <p>Username: {user.username}</p>
        <p>Email: {user.email}</p>
        {/* Add more user profile information here */}
      </div>
      <a className="profile-link" href='/employee'>Create Employee</a>
    </div>
  );
};

export default Profile;
